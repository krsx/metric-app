package com.capstone.metricapp.core.utils

enum class FabMenuState {
    COLLAPSED,
    EXPANDED
}